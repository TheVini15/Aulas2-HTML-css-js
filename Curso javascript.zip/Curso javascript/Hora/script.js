function carregar() {
  var msg = document.getElementById('msg');
  var img = document.getElementById('img');
  var body = document.querySelector("body#color")

  var date = new Date();
  var hora = date.getHours();
  msg.innerText = `Agora são ${hora} horas`;
  if (hora >= 0 && hora < 12) {
    img.src = 'imagens/tanhã.png';
  } else if (hora >= 12 && hora < 18) {
    img.src = 'imagens/tarde.png';
      body.style.background = 'orange'
  } else {
    img.src = 'imagens/toite.png'
      body.style.background = 'gray'
  }
}