function Tabuada(){
  var num = document.querySelector("input#txtn")
  var Tab = document.querySelector("select#seltab")
  if (num.value.length == 0) {
  window.alert('digite um número')
  } else {
  var n = Number(num.value)
  var c = 1
  Tab.innerHTML = ''
  while (c <= 10){
    var item = document.createElement('option')
    item.text = `${n} X ${c} = ${n*c}`
    Tab.appendChild(item)
    c++
  }
  }
}