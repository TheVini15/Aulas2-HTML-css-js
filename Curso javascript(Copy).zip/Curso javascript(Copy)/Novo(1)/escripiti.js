function contar(){
  var inicio = document.querySelector('input#inicio')
  var fim = document.querySelector('input#fim')
  var passo = document.querySelector('input#passo')
  var inicio1 = Number(inicio.value)
  var fim1 = Number(fim.value)
  var passo1 = Number(passo.value)
  var res = document.querySelector("div#res")
  if (inicio.value === '' || fim.value === '' || passo.value === '') {
  window.alert("digite os números ")
}else if (inicio.value > fim.value){
  window.alert("digite da forma correta")
}else{
  while (inicio1 <= fim1){
  res.innerHTML += ` \u{1F449}${inicio1}`
  inicio1 += passo1
  }
}
}