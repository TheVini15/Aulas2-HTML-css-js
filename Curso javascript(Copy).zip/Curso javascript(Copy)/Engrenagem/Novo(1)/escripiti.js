function confirmar(){
  var nome = document.querySelector("input#nome")
  var senha = document.querySelector("input#senha")
  var nome1 = document.querySelector("p1#nome1")
  var senha1 = document.querySelector("p1#senha1")
  var confi = document.querySelector("div#res")
  var confi1 = confi.length
  var senhac = 'vinicius15!!'
  var nomec = 'Thevini15'
  if (nome.value === '' && senha.value === ''){
  nome1.style.color = 'red'
  senha1.style.color = 'red'
  }else if (nome.value === ''){
  nome1.style.color = 'red' 
  }else if (senha.value === ''){
  senha1.style.color = 'red'
  }
  function entrar(){
    nome.style.color = 'blue'
  }
  function sair(){
    nome.style.color = 'white'
  }
  function entrar1(){
    senha.style.color = 'blue'
  }
  function sair1(){
    senha.style.color = 'white'
  }