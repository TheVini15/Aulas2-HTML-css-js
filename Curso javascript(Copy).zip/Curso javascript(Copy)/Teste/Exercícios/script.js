function verificar(){
  var data = new Date()
  var ano = data.getFullYear()
  var fano = document.querySelector("input#n1")
  var res = document.querySelector("div#res")
  var img = document.createElement("img")
  img.setAttribute('id','foto')
  if (fano.value.length == 0 || fano.value > ano){
    window.alert("[ERRO]verique os dados novamente")
  } else{
    var fsex = document.getElementsByName("radsex")
    var idade = ano - Number(fano.value)
    res.innerHTML = `idade calculada: ${idade}`
    if (fsex[0].checked){
      gênero = "homem"
      if (idade >=0 && idade <10){
        img.setAttribute('src','imagens/criança m.jpeg')
      }else if (idade > 10 && idade <21){
        img.setAttribute('src','imagens/adolescente m.jpeg')
      }else if (idade <= 50){
       img.setAttribute('src','imagens/adulto m.jpeg')
      }
      else{
       img.setAttribute('src','imagens/idoso m.jpeg')
      }
    } else if (fsex[1].checked){
      gênero = "mulher"
            if (idade >=0 && idade <10){
        img.setAttribute('src','imagens/criança f.jpeg')
      }else if (idade > 10 && idade <21){
        img.setAttribute('src','imagens/adolescente f.jpeg')
      }else if (idade < 50){
       img.setAttribute('src','imagens/adolescente f.jpeg')
      }
      else{
        img.setAttribute('src','imagens/idoso f.jpeg')
      }
    }
    res.style.textAlign = "center"
    res.innerHTML = `detectamos ${gênero} com ${idade} anos.`
    res.appendChild(img)
  }
}