import pygame
import sys

# Inicializa o Pygame
pygame.init()

# Define as dimensões da janela
largura = 800
altura = 600

# Define as dimensões do labirinto
labirinto = [
    "XXXXXXXXXXXXXXXXXXXX",
    "X       X          X",
    "X XXXXX X XXXXXXXX X",
    "X X   X X X      X X",
    "X X X X X XXXXXX X X",
    "X X X X X X      X X",
    "X X X X X X XXXX X X",
    "X X X X X X X  X X X",
    "X X X X X X XXXX X X",
    "X X X X X X      X X",
    "X X X X X X XXXXXX X",
    "X X X X X X      X X",
    "X X X X X XXXXXXXX X",
    "X X X X X          X",
    "X X X X X XXXXXXXX X",
    "X X X X X X      X X",
    "X X X X X X XXXX X X",
    "X X X X X X X  X X X",
    "X X X X X X XXXX X X",
    "X X X X X X      X X",
    "XXXXXXXXXXXXXXXXXXXX",
]

# Define as cores
cor_fundo = (255, 255, 255)
cor_parede = (0, 0, 0)
cor_personagem = (255, 0, 0)

# Define as dimensões do personagem
tam_personagem = 30

# Define a velocidade do personagem
velocidade = 5

# Define a classe do personagem
class Personagem:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def desenhar(self, janela):
        pygame.draw.rect(janela, cor_personagem, (self.x, self.y, tam_personagem, tam_personagem))

    def mover(self, dx, dy):
        if labirinto[int((self.y + dy) / tam_personagem)][int((self.x + dx) / tam_personagem)] == " ":
            self.x += dx
            self.y += dy

# Define a classe das paredes
class Parede:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def desenhar(self, janela):
        pygame.draw.rect(janela, cor_parede, (self.x, self.y, tam_personagem, tam_personagem))

# Define a função para desenhar o labirinto
def desenhar_labirinto(janela):
    for i in range(len(labirinto)):
        for j in range(len(labirinto[i])):
            if labirinto[i][j] == "X":
                parede = Parede(j * tam_personagem, i * tam_personagem)
                parede.desenhar(janela)

# Define a função para detectar colisões
def detectar_colisoes(personagem):
    for i in range(len(labirinto)):
        for j in range(len(labirinto[i])):
            if labirinto[i][j] == "X":
                parede = Parede(j * tam_personagem, i * tam_personagem)
                if personagem.x < parede.x + tam_personagem and personagem.x + tam_personagem > parede.x and personagem.y < parede.y + tam_personagem and personagem.y + tam_personagem > parede.y:
                    return True
    return False

# Cria a janela
janela = pygame.display.set_mode((largura, altura))

# Define o personagem
personagem = Personagem(0, 0)

# Loop principal do jogo
while True:
    # Verifica eventos do Pygame
    for evento in pygame.event.get():
        # Se o evento for o fechamento da janela
        if evento.type == pygame.QUIT:
            # Sai do programa
            pygame.quit()
            sys.exit()

    # Preenche a janela com a cor de fundo
    janela.fill(cor_fundo)

    # Desenha o labirinto
    desenhar_labirinto(janela)

    # Desenha o personagem
    personagem.desenhar(janela)

    # Movimenta o personagem
    teclas = pygame.key.get_pressed()
    if teclas[pygame.K_LEFT]:
        personagem.mover(-velocidade, 0)
    if teclas[pygame.K_RIGHT]:
        personagem.mover(velocidade, 0)
    if teclas[pygame.K_UP]:
        personagem.mover(0, -velocidade)
    if teclas[pygame.K_DOWN]:
        personagem.mover(0, velocidade)

    # Verifica colisões
    if detectar_colisoes(personagem):
        personagem.mover(-velocidade, 0)

    # Atualiza a tela
    pygame.display.update()